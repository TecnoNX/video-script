<?php
$themeName = 'VidPlay';

$themeFolder = 'vidplay';

$themeAuthor = 'Kulvir Singh';

$themeAuthorUrl = 'http://bit.ly/kb97';

$themeVirsion = '1.9';
?>